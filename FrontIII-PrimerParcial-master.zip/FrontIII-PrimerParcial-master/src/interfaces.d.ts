export interface FormData {
    name: string;
    lastName: string;
}