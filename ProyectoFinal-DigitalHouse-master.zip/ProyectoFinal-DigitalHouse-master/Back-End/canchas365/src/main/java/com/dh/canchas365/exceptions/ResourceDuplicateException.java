package com.dh.canchas365.exceptions;

public class ResourceDuplicateException extends Exception{
    public ResourceDuplicateException(String message){
        super(message);
    }
}
