package com.dh.canchas365;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Canchas365Application {

	public static void main(String[] args) {
		SpringApplication.run(Canchas365Application.class, args);
	}

}
