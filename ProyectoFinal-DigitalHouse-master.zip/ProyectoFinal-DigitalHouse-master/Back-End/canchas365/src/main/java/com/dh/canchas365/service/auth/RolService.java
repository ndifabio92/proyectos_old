package com.dh.canchas365.service.auth;

import org.springframework.stereotype.Service;

@Service
public class RolService {

}
