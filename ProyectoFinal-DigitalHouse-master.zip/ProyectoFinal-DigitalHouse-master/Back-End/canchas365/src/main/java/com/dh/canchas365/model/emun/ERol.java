package com.dh.canchas365.model.emun;

public enum ERol {
    ADMIN, USER
}
