package com.dh.canchas365;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Canchas365ApplicationTests {

	@Test
	void contextLoads() {
	}

}
