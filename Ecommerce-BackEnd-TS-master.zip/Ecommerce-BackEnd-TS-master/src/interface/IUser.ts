interface IUser {
    firstName: string;
    lastName: string;
    email: string;
    age: number;
    password: string;
}

export default IUser;