interface ILogin {
    email: string;
    password: string;
}


export default ILogin;